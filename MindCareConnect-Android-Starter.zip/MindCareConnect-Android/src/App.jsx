import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare, Heart, ShieldAlert, Clock, Smartphone,
  Palette, Users, Sparkles, Send, AlertTriangle, Activity,
  CheckCircle2, Smile, Frown, Meh, Lock, LogOut,
  BookOpen, Zap, Volume2, VolumeX, Wind,
  LogIn, School, ArrowRight, CheckCircle, ShieldCheck
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar
} from 'recharts';

const THEMES = {
  sakura: {
    id: 'sakura',
    name: '🌸 Sakura Pastel',
    tagline: 'Lembut, tenang & merah jambu bunga ceri',
    bg: 'bg-gradient-to-br from-rose-100 via-pink-50 to-rose-200 text-slate-800',
    card: 'bg-white/85 backdrop-blur-md border-rose-200/80 text-slate-800 shadow-md shadow-rose-100/50',
    primary: 'bg-rose-400 hover:bg-rose-500 text-white shadow-rose-200',
    accent: 'text-rose-500',
    border: 'border-rose-200',
    chatUser: 'bg-rose-400 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-white/90 text-rose-950 border border-rose-100 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-rose-200/60 backdrop-blur-md',
    subtext: 'text-rose-600/70',
    mascotColor: '#f43f5e',
    badgeBg: 'bg-rose-100 text-rose-600',
    accentGradient: 'from-rose-400 to-pink-500',
  },
  matcha: {
    id: 'matcha',
    name: '🍵 Matcha Zen',
    tagline: 'Segar bagaikan ladang teh & alam semulajadi',
    bg: 'bg-gradient-to-br from-emerald-100 via-teal-50 to-green-100 text-emerald-950',
    card: 'bg-white/85 backdrop-blur-md border-emerald-200/80 text-emerald-950 shadow-md shadow-emerald-100/50',
    primary: 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200',
    accent: 'text-emerald-600',
    border: 'border-emerald-200',
    chatUser: 'bg-emerald-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-emerald-50/90 text-emerald-900 border border-emerald-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-emerald-200/60 backdrop-blur-md',
    subtext: 'text-emerald-700/70',
    mascotColor: '#059669',
    badgeBg: 'bg-emerald-100 text-emerald-700',
    accentGradient: 'from-emerald-500 to-teal-600',
  },
  midnight: {
    id: 'midnight',
    name: '🌌 Starry Midnight',
    tagline: 'Langit malam yang sunyi & dipenuhi bintang',
    bg: 'bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-indigo-100',
    card: 'bg-indigo-950/60 backdrop-blur-md border-indigo-800/50 text-indigo-100 shadow-xl shadow-indigo-950/50',
    primary: 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-indigo-900',
    accent: 'text-indigo-300',
    border: 'border-indigo-800/60',
    chatUser: 'bg-indigo-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-slate-900/90 text-indigo-100 border border-indigo-800/60 rounded-bl-none shadow-sm',
    navBg: 'bg-slate-950/80 border-indigo-900/60 backdrop-blur-md',
    subtext: 'text-indigo-300/70',
    mascotColor: '#818cf8',
    badgeBg: 'bg-indigo-900/50 text-indigo-300',
    accentGradient: 'from-indigo-500 to-purple-600',
  },
  boba: {
    id: 'boba',
    name: '🧋 Boba Milk Tea',
    tagline: 'Hangat, selesa & rona karamel teh ais',
    bg: 'bg-gradient-to-br from-amber-100 via-orange-50 to-stone-100 text-stone-800',
    card: 'bg-white/90 backdrop-blur-md border-amber-200/80 text-stone-800 shadow-md shadow-amber-100/50',
    primary: 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-200',
    accent: 'text-amber-700',
    border: 'border-amber-200',
    chatUser: 'bg-amber-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-amber-50/90 text-stone-800 border border-amber-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-amber-200/60 backdrop-blur-md',
    subtext: 'text-amber-800/70',
    mascotColor: '#d97706',
    badgeBg: 'bg-amber-100 text-amber-800',
    accentGradient: 'from-amber-500 to-orange-600',
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: '🎮 Neon Gamer',
    tagline: 'Vibe futuristic, bertenaga & lampu neon',
    bg: 'bg-slate-950 text-cyan-300 font-sans',
    card: 'bg-slate-900/90 backdrop-blur-md border-cyan-500/30 text-cyan-200 shadow-lg shadow-cyan-950/50',
    primary: 'bg-pink-600 hover:bg-pink-500 text-white font-bold shadow-pink-900/50',
    accent: 'text-pink-400',
    border: 'border-cyan-500/30',
    chatUser: 'bg-pink-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-slate-900 text-cyan-200 border border-cyan-500/30 rounded-bl-none shadow-sm',
    navBg: 'bg-slate-950/90 border-cyan-500/30 backdrop-blur-md',
    subtext: 'text-cyan-400/70',
    mascotColor: '#ec4899',
    badgeBg: 'bg-cyan-950 text-cyan-300 border border-cyan-500/40',
    accentGradient: 'from-pink-500 to-cyan-500',
  },
  ocean: {
    id: 'ocean',
    name: '🌊 Ocean Waves',
    tagline: 'Ketenangan samudera biru & angin laut',
    bg: 'bg-gradient-to-br from-cyan-100 via-sky-50 to-blue-100 text-sky-950',
    card: 'bg-white/85 backdrop-blur-md border-sky-200/80 text-sky-950 shadow-md shadow-sky-100/50',
    primary: 'bg-sky-600 hover:bg-sky-700 text-white shadow-sky-200',
    accent: 'text-sky-600',
    border: 'border-sky-200',
    chatUser: 'bg-sky-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-sky-50/90 text-sky-950 border border-sky-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-sky-200/60 backdrop-blur-md',
    subtext: 'text-sky-700/70',
    mascotColor: '#0284c7',
    badgeBg: 'bg-sky-100 text-sky-700',
    accentGradient: 'from-sky-400 to-blue-600',
  },
  lavender: {
    id: 'lavender',
    name: '🔮 Lavender Dream',
    tagline: 'Imaginatif, romantis & damai purple pastel',
    bg: 'bg-gradient-to-br from-purple-100 via-fuchsia-50 to-purple-200 text-purple-950',
    card: 'bg-white/85 backdrop-blur-md border-purple-200/80 text-purple-950 shadow-md shadow-purple-100/50',
    primary: 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200',
    accent: 'text-purple-600',
    border: 'border-purple-200',
    chatUser: 'bg-purple-600 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-purple-50/90 text-purple-950 border border-purple-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-purple-200/60 backdrop-blur-md',
    subtext: 'text-purple-700/70',
    mascotColor: '#9333ea',
    badgeBg: 'bg-purple-100 text-purple-700',
    accentGradient: 'from-purple-500 to-fuchsia-600',
  },
  sunset: {
    id: 'sunset',
    name: '🌆 Sunset Glow',
    tagline: 'Suasana senja yang estetik & hangat',
    bg: 'bg-gradient-to-br from-orange-100 via-amber-50 to-rose-100 text-stone-800',
    card: 'bg-white/85 backdrop-blur-md border-orange-200/80 text-stone-800 shadow-md shadow-orange-100/50',
    primary: 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-200',
    accent: 'text-orange-600',
    border: 'border-orange-200',
    chatUser: 'bg-orange-500 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-orange-50/90 text-stone-800 border border-orange-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-orange-200/60 backdrop-blur-md',
    subtext: 'text-orange-700/70',
    mascotColor: '#f97316',
    badgeBg: 'bg-orange-100 text-orange-700',
    accentGradient: 'from-orange-400 to-rose-500',
  },
  teddy: {
    id: 'teddy',
    name: '🧸 Cozy Teddy',
    tagline: 'Gaya vintaj vintaj, hangat & comel',
    bg: 'bg-gradient-to-br from-yellow-100/60 via-amber-50 to-stone-200 text-stone-800',
    card: 'bg-white/90 backdrop-blur-md border-amber-300/60 text-stone-800 shadow-md shadow-stone-200/50',
    primary: 'bg-stone-700 hover:bg-stone-800 text-white shadow-stone-300',
    accent: 'text-amber-800',
    border: 'border-amber-300/60',
    chatUser: 'bg-stone-700 text-white rounded-br-none shadow-sm',
    chatAi: 'bg-stone-100 text-stone-900 border border-amber-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-amber-200/60 backdrop-blur-md',
    subtext: 'text-stone-600',
    mascotColor: '#78350f',
    badgeBg: 'bg-amber-100 text-amber-900',
    accentGradient: 'from-amber-700 to-stone-800',
  },
  lemon: {
    id: 'lemon',
    name: '🍋 Lemon Fresh',
    tagline: 'Ceria, bersemangat & penuh kegembiraan',
    bg: 'bg-gradient-to-br from-amber-100 via-yellow-50 to-emerald-100 text-slate-800',
    card: 'bg-white/90 backdrop-blur-md border-yellow-300/80 text-slate-800 shadow-md shadow-yellow-100/50',
    primary: 'bg-yellow-500 hover:bg-yellow-600 text-slate-950 font-bold shadow-yellow-200',
    accent: 'text-amber-600',
    border: 'border-yellow-200',
    chatUser: 'bg-yellow-500 text-slate-950 font-semibold rounded-br-none shadow-sm',
    chatAi: 'bg-yellow-50/90 text-slate-800 border border-yellow-200 rounded-bl-none shadow-sm',
    navBg: 'bg-white/80 border-yellow-200/60 backdrop-blur-md',
    subtext: 'text-amber-700/70',
    mascotColor: '#eab308',
    badgeBg: 'bg-yellow-100 text-yellow-800',
    accentGradient: 'from-yellow-400 to-emerald-400',
  }
};

const SCREEN_TIME_DATA = [
  { day: 'Isnin', totalMinutes: 240, social: 110, gaming: 80, study: 50 },
  { day: 'Selasa', totalMinutes: 195, social: 90, gaming: 60, study: 45 },
  { day: 'Rabu', totalMinutes: 280, social: 140, gaming: 90, study: 30 },
  { day: 'Khamis', totalMinutes: 310, social: 160, gaming: 110, study: 40 },
  { day: 'Jumaat', totalMinutes: 260, social: 120, gaming: 95, study: 45 },
  { day: 'Sabtu', totalMinutes: 380, social: 180, gaming: 150, study: 50 },
  { day: 'Ahad', totalMinutes: 320, social: 150, gaming: 120, study: 50 },
];

const APP_USAGE_PIE = [
  { name: 'Media Sosial (TikTok/IG)', value: 42, color: '#ec4899' },
  { name: 'Permainan Video', value: 28, color: '#8b5cf6' },
  { name: 'Sembang & Mesej', value: 18, color: '#06b6d4' },
  { name: 'Pembelajaran & Lain-lain', value: 12, color: '#10b981' },
];

const MOOD_TREND = [
  { time: 'Isnin', score: 7, label: 'Ceria' },
  { time: 'Selasa', score: 6, label: 'Biasa' },
  { time: 'Rabu', score: 4, label: 'Gelisah' },
  { time: 'Khamis', score: 3, label: 'Sedih' },
  { time: 'Jumaat', score: 5, label: 'Biasa' },
  { time: 'Sabtu', score: 8, label: 'Gembira' },
  { time: 'Ahad', score: 6, label: 'Biasa' },
];

class SoothingSoundSynth {
  constructor() {
    this.ctx = null;
    this.noiseNode = null;
    this.gainNode = null;
    this.isPlaying = false;
  }

  startRain() {
    if (this.isPlaying) this.stop();
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();
      
      const bufferSize = 2 * this.ctx.sampleRate;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = output[i];
      }

      this.noiseNode = this.ctx.createBufferSource();
      this.noiseNode.buffer = noiseBuffer;
      this.noiseNode.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, this.ctx.currentTime);

      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.12, this.ctx.currentTime);

      this.noiseNode.connect(filter);
      filter.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);

      this.noiseNode.start();
      this.isPlaying = true;
    } catch (e) {
      console.warn("Audio Context error:", e);
    }
  }

  stop() {
    if (this.gainNode && this.ctx) {
      try {
        this.gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.5);
        setTimeout(() => {
          this.noiseNode?.stop();
          this.ctx?.close();
          this.isPlaying = false;
        }, 500);
      } catch (e) {
        this.isPlaying = false;
      }
    } else {
      this.isPlaying = false;
    }
  }
}

const audioSynth = new SoothingSoundSynth();

function CuteMascot({ mood = 'happy', size = 'normal', onClick = null, quote = '' }) {
  const isSmall = size === 'small';
  const isLarge = size === 'large';
  const widthClass = isSmall ? 'w-12 h-12' : isLarge ? 'w-28 h-28' : 'w-20 h-20';

  return (
    <div
      onClick={onClick}
      className={`relative group flex flex-col items-center justify-center cursor-pointer transition-transform duration-300 hover:scale-110 active:scale-95`}
    >
      <div className={`relative ${widthClass} flex items-center justify-center`}>
        <div className="absolute inset-0 bg-pink-300/30 rounded-full blur-xl animate-pulse" />
        <svg viewBox="0 0 120 100" className="w-full h-full drop-shadow-md overflow-visible">
          <path
            d="M 30,70 
               C 10,70 5,50 25,40 
               C 20,20 45,10 65,25 
               C 80,10 105,20 100,40 
               C 115,50 110,70 90,70 Z"
            fill="#FFFFFF"
            stroke="#e2e8f0"
            strokeWidth="3"
          />
          <circle cx="35" cy="48" r="6" fill="#f472b6" opacity="0.6" />
          <circle cx="85" cy="48" r="6" fill="#f472b6" opacity="0.6" />

          {mood === 'happy' && (
            <>
              <path d="M 40,40 Q 46,32 52,40" fill="none" stroke="#334155" strokeWidth="3.5" strokeLinecap="round" />
              <path d="M 68,40 Q 74,32 80,40" fill="none" stroke="#334155" strokeWidth="3.5" strokeLinecap="round" />
              <path d="M 54,48 Q 60,55 66,48" fill="none" stroke="#334155" strokeWidth="3" strokeLinecap="round" />
            </>
          )}

          {mood === 'breathing' && (
            <>
              <path d="M 40,38 Q 46,44 52,38" fill="none" stroke="#334155" strokeWidth="3.5" strokeLinecap="round" />
              <path d="M 68,38 Q 74,44 80,38" fill="none" stroke="#334155" strokeWidth="3.5" strokeLinecap="round" />
              <circle cx="60" cy="50" r="3" fill="#334155" />
            </>
          )}

          {mood === 'supportive' && (
            <>
              <circle cx="46" cy="38" r="3" fill="#334155" />
              <circle cx="74" cy="38" r="3" fill="#334155" />
              <path d="M 52,46 Q 60,56 68,46 Z" fill="#f43f5e" />
              <path d="M 60,10 C 58,5 50,5 50,12 C 50,17 60,22 60,22 C 60,22 70,17 70,12 C 70,5 62,5 60,10 Z" fill="#ec4899" className="animate-bounce" />
            </>
          )}

          <ellipse cx="45" cy="72" rx="6" ry="4" fill="#cbd5e1" />
          <ellipse cx="75" cy="72" rx="6" ry="4" fill="#cbd5e1" />
        </svg>
      </div>

      {quote && (
        <div className="mt-1 px-3 py-1 bg-white/90 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 text-[11px] font-medium rounded-full border border-slate-200/80 dark:border-slate-700 shadow-sm animate-fade-in text-center">
          {quote}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentRole, setCurrentRole] = useState('student'); // 'student' | 'parent' | 'counselor'
  const [themeKey, setThemeKey] = useState('sakura');

  // DELIMa Identity State
  const [delimaId, setDelimaId] = useState('');
  const [password, setPassword] = useState('');
  const [userProfile, setUserProfile] = useState(null);
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Audio State
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  // Mascot state
  const [mascotMood, setMascotMood] = useState('happy');
  const [mascotQuote, setMascotQuote] = useState('Hai! Ketuk saya untuk pelukan maya! 💖');

  // Breathing Exercise Modal State
  const [showBreathingModal, setShowBreathingModal] = useState(false);
  const [breathingPhase, setBreathingPhase] = useState('Tarikh Nafas (Inhale)');
  const [breathingTimer, setBreathingTimer] = useState(4);

  // Student Chat & Check-in State
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'ai',
      text: 'Selamat datang ke MindCare Connect DELIMa! ☁️ Saya Mochi, kawan AI yang sentiasa ada bersama awak. Hari ini awak rasa macam mana? Ceritalah apa-apa sahaja, Mochi dengar tau! 😊✨',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [showCheckupModal, setShowCheckupModal] = useState(false);
  const [checkupMood, setCheckupMood] = useState(null);
  const [checkupNote, setCheckupNote] = useState('');
  const [checkupDone, setCheckupDone] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);

  // Students Directory
  const [studentsList, setStudentsList] = useState([
    {
      id: 'm-10293841',
      name: 'Ahmad Daniel (g-10293841)',
      class: 'Tingkatan 4 Melati',
      email: 'g-10293841@moe-dl.edu.my',
      riskLevel: 'Tinggi',
      lastActive: 'Hari ini, 10:12 AM',
      moodIndex: 'Sangat Sedih / Tertekan',
      aiSummary: 'Meluahkan rasa putus asa yang melampau mengenai tekanan hidup dan persekolahan. Memerlukan perhatian kaunselor segera.',
      counselorAction: 'Belum Intervensi',
      avatarColor: 'bg-rose-500'
    },
    {
      id: 'm-20394812',
      name: 'Siti Nurhaliza (g-20394812)',
      class: 'Tingkatan 2 Teratai',
      email: 'g-20394812@moe-dl.edu.my',
      riskLevel: 'Sederhana',
      lastActive: 'Semalam, 04:45 PM',
      moodIndex: 'Bimbang / Gelisah',
      aiSummary: 'Berasa cemas akibat komen negatif di media sosial oleh rakan sekelas dan sedikit enggan hadir ke sekolah.',
      counselorAction: 'Sesi Kelompok Terancang',
      avatarColor: 'bg-amber-500'
    },
    {
      id: 'm-30495823',
      name: 'Adam Rayyan (g-30495823)',
      class: 'Tingkatan 5 Alfa',
      email: 'g-30495823@moe-dl.edu.my',
      riskLevel: 'Ringan',
      lastActive: 'Hari ini, 01:20 PM',
      moodIndex: 'Sedikit Penat / Stabil',
      aiSummary: 'Sedikit keletihan ulangkaji pelajaran SPM tetapi motivasi diri masih berada pada tahap positif.',
      counselorAction: 'Pemantauan Rutin',
      avatarColor: 'bg-emerald-500'
    }
  ]);

  // Parent Hints
  const [parentHints, setParentHints] = useState([
    {
      id: 1,
      date: 'Hari ini, 02:15 PM',
      category: 'Tekanan Rakan Sebaya / Keletihan Emosi',
      level: 'Sederhana',
      hint: 'Anak anda mungkin sedang mengalami perasaan tersisih daripada kumpulan rakan atau kekecewaan emosi ringan dalam perhubungan sosial.',
      advice: 'Ajak anak anda makan hidangan kegemaran mereka malam ini. Mulakan perbualan santai tentang hobi atau rancangan minggu ini tanpa terus bertanyakan isu sekolah.',
      unread: true
    },
    {
      id: 2,
      date: 'Semalam, 09:40 PM',
      category: 'Beban Akademik',
      level: 'Ringan',
      hint: 'Terdapat bayangan bahawa anak anda berasa bimbang dengan persediaan peperiksaan dan takut mengecewakan harapan orang sekeliling.',
      advice: 'Berikan sokongan moral secara terbuka. Ingatkan mereka bahawa kesihatan dan kebahagiaan mereka lebih penting daripada sekadar gred.'
    }
  ]);

  // Crisis Alerts
  const [crisisAlerts, setCrisisAlerts] = useState([
    {
      id: 'CR-8821',
      studentName: 'Ahmad Daniel (g-10293841@moe-dl.edu.my)',
      studentEmail: 'g-10293841@moe-dl.edu.my',
      timestamp: 'Hari ini, 10:12 AM',
      severity: 'KRITIKAL (Merah)',
      issueType: 'Kecenderungan Mencederakan Diri / Kemurungan Akut',
      aiSummary: 'Pelajar meluahkan keletihan hidup yang terlampau dan menyebut perkataan berisiko tinggi berkaitan keputusasaan.',
      status: 'BELUM DIPROSES',
      recommendedAction: 'Perlu intervensi kaunseling bersemuka serta-merta dan pemantauan khas.'
    }
  ]);

  const activeTheme = THEMES[themeKey] || THEMES.sakura;
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleDelimaLogin = (e) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    setTimeout(() => {
      const emailLower = delimaId.trim().toLowerCase();

      // Check DELIMa domain rules or auto-detect role based on ID prefix/format
      let detectedRole = currentRole;
      let userName = 'Pengguna DELIMa MOE';

      if (currentRole === 'student') {
        if (!emailLower.includes('@moe-dl.edu.my') && !emailLower.includes('@dl.moe.edu.my') && !emailLower.startsWith('g-')) {
          setLoginError('Sila gunakan ID DELIMa Murid rasmi (Contoh: g-12345678@moe-dl.edu.my)');
          setIsLoggingIn(false);
          return;
        }
        userName = `Pelajar (${emailLower.split('@')[0]})`;
      } else if (currentRole === 'counselor') {
        if (!emailLower.includes('@moe-dl.edu.my') && !emailLower.includes('@dl.moe.edu.my') && !emailLower.startsWith('g-')) {
          setLoginError('Sila gunakan ID DELIMa Guru/Kaunselor rasmi (Contoh: g-98765432@moe-dl.edu.my)');
          setIsLoggingIn(false);
          return;
        }
        userName = `Guru Kaunselor (${emailLower.split('@')[0]})`;
      } else if (currentRole === 'parent') {
        if (!emailLower.includes('@') || password.length < 4) {
          setLoginError('Sila masukkan e-mel pendaftaran ibu bapa dan kata laluan sah.');
          setIsLoggingIn(false);
          return;
        }
        userName = `Ibu Bapa / Penjaga (${emailLower})`;
      }

      setUserProfile({
        delimaId: emailLower,
        name: userName,
        role: currentRole
      });

      setIsLoggingIn(false);
      setIsLoggedIn(true);
    }, 1000);
  };

  const handleMascotTap = () => {
    const quotes = [
      'Awak buat yang terbaik hari ni! 💖',
      'Jangan lupa minum air & ambil nafas dalam-dalam 🌸',
      'Mochi sentiasa ada di sini untuk awak ✨',
      'Senyum sikit! Awak comel bila senyum 😊',
      'Setiap langkah kecil tetap satu kemajuan! 🐾'
    ];
    setMascotQuote(quotes[Math.floor(Math.random() * quotes.length)]);
    setMascotMood('supportive');
    setTimeout(() => setMascotMood('happy'), 2500);
  };

  const toggleAudio = () => {
    if (isAudioPlaying) {
      audioSynth.stop();
      setIsAudioPlaying(false);
    } else {
      audioSynth.startRain();
      setIsAudioPlaying(true);
    }
  };

  useEffect(() => {
    let interval = null;
    if (showBreathingModal) {
      interval = setInterval(() => {
        setBreathingTimer((prev) => {
          if (prev <= 1) {
            setBreathingPhase((phase) => {
              if (phase === 'Tarikh Nafas (Inhale)') return 'Tahan Nafas (Hold)';
              if (phase === 'Tahan Nafas (Hold)') return 'Hembus Nafas (Exhale)';
              return 'Tarikh Nafas (Inhale)';
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showBreathingModal]);

  const handleSendMessage = async (e) => {
    e?.preventDefault();
    if (!inputText.trim()) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    const currentInput = inputText;
    setInputText('');
    setIsThinking(true);

    try {
      const apiKey = "";
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

      const systemPrompt = `Anda adalah Mochi, maskot awan AI yang amat comel, mesra, dan berhati lembut untuk pelajar sekolah yang log masuk melalui DELIMa KPM.
Aturan penting jawapan anda:
1. Guna bahasa Melayu santai, penyayang dan comel (contoh: "Awak", "Mochi", "Kawan").
2. Masukkan emoji comel (☁️, ✨, 🌸, 💖, 🐾).
3. Ayat mestilah RINGKAS (2-3 ayat sahaja) untuk menenangkan fikiran pelajar.
4. Akhiri dengan soalan pendek yang lembut untuk galakkan mereka cerita lebih.`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            { role: 'user', parts: [{ text: `${systemPrompt}\n\nLuahan Pelajar DELIMa: ${currentInput}` }] }
          ]
        })
      });

      const data = await response.json();
      const aiReplyText = data?.candidates?.[0]?.content?.parts?.[0]?.text || generateFallbackReply(currentInput);

      setMessages((prev) => [...prev, {
        id: Date.now() + 1,
        sender: 'ai',
        text: aiReplyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);

      analyzeConversationAndTriggerAlerts(currentInput);

    } catch (err) {
      setTimeout(() => {
        setMessages((prev) => [...prev, {
          id: Date.now() + 1,
          sender: 'ai',
          text: generateFallbackReply(currentInput),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
        analyzeConversationAndTriggerAlerts(currentInput);
      }, 800);
    } finally {
      setIsThinking(false);
    }
  };

  const generateFallbackReply = (text) => {
    const lower = text.toLowerCase();
    if (lower.includes('sedih') || lower.includes('kecewa') || lower.includes('nangis')) {
      return "Kesiannya awak... 🌸 Meh sini Mochi peluk jauh-jauh! Tak apa kalau nak rasa sedih. Boleh Mochi tahu apa yang terjadi?";
    }
    if (lower.includes('buli') || lower.includes('kawan') || lower.includes('pulau')) {
      return "Kawan buat begitu ya? Mochi faham rasa sakit hati tu. Tapi ingat tau, awak seorang yang berharga! Nak cerita lebih kat Mochi?";
    }
    if (lower.includes('mati') || lower.includes('bunuh') || lower.includes('sakitkan')) {
      return "Awak sangat berharga untuk Mochi dan dunia ni 💖 Tolong jangan sakitkan diri ya. Mochi ada di sini, jom borak dengan Mochi?";
    }
    return "Terima kasih sebab sudi berkongsi cerita dengan Mochi! ☁️ Mochi suka dengar cerita awak. Boleh cerita lagi?";
  };

  const analyzeConversationAndTriggerAlerts = (text) => {
    const lower = text.toLowerCase();
    const activeEmail = userProfile?.delimaId || 'g-pelajar@moe-dl.edu.my';
    
    if (lower.includes('bunuh') || lower.includes('mati') || lower.includes('keluar dari dunia') || lower.includes('sakitkan diri')) {
      const newCrisis = {
        id: `CR-${Math.floor(1000 + Math.random() * 9000)}`,
        studentName: `${userProfile?.name || 'Pelajar DELIMa'} (${activeEmail})`,
        studentEmail: activeEmail,
        timestamp: 'Baru Sahaja',
        severity: 'KRITIKAL (Merah)',
        issueType: 'Risiko Keselamatan / Keputusasaan',
        aiSummary: `AI mengesan ekspresi berisiko tinggi dalam luahan terkini: "${text.substring(0, 50)}..."`,
        status: 'BELUM DIPROSES',
        recommendedAction: 'Segera aturkan sesi pertemuan peribadi dengan pelajar.'
      };
      setCrisisAlerts((prev) => [newCrisis, ...prev]);

      setStudentsList((prev) =>
        prev.map((s) =>
          s.email === activeEmail
            ? { ...s, riskLevel: 'Tinggi', aiSummary: `[RISIKO TINGGI DETECTED] ${text.substring(0, 80)}...`, lastActive: 'Baru Sahaja' }
            : s
        )
      );
    } else if (lower.includes('reject') || lower.includes('crush') || lower.includes('suka') || lower.includes('sedih kawan')) {
      const newHint = {
        id: Date.now(),
        date: 'Baru Sahaja',
        category: 'Isu Perhubungan Sosial & Emosi',
        level: 'Sederhana',
        hint: 'Anak anda mungkin sedang menghadapi sedikit perasaan kecewa atau penolakan emosi dalam lingkungan sosial rakan sebaya.',
        advice: 'Jangan terus bertanyakan mengenai isu tersebut. Luangkan masa berjalan di taman atau nikmati makanan kegemaran bersama.',
        unread: true
      };
      setParentHints((prev) => [newHint, ...prev]);
    }
  };

  const handleCompleteCheckup = () => {
    if (!checkupMood) return;
    setCheckupDone(true);
    setTimeout(() => {
      setShowCheckupModal(false);
      setCheckupDone(false);
      setCheckupMood(null);
      setCheckupNote('');
    }, 1500);
  };

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen ${activeTheme.bg} flex items-center justify-center p-4 transition-all duration-500 font-sans`}>
        <div className={`max-w-lg w-full p-8 rounded-3xl ${activeTheme.card} border ${activeTheme.border} shadow-2xl backdrop-blur-xl relative overflow-hidden`}>
          
          {/* DELIMa Official Header Branding */}
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-6">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-xl shadow-md">
                D
              </div>
              <div>
                <h2 className="font-black text-sm tracking-wide uppercase text-blue-600 dark:text-blue-400">
                  DELIMa MOE Malaysia
                </h2>
                <p className="text-[11px] text-slate-500 font-semibold">Portal Akses Kebajikan Emosi Pelajar</p>
              </div>
            </div>
            <ShieldCheck className="w-6 h-6 text-emerald-500" />
          </div>

          <div className="text-center mb-6">
            <div className="mx-auto mb-2 flex justify-center">
              <CuteMascot mood="happy" size="large" onClick={handleMascotTap} quote={mascotQuote} />
            </div>
            <h1 className="text-2xl font-black tracking-tight mt-2 bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-rose-500 to-indigo-600">
              MindCare Connect
            </h1>
            <p className={`text-xs mt-1 ${activeTheme.subtext}`}>Sila Log Masuk Menggunakan Akaun DELIMa KPM Anda</p>
          </div>

          <form onSubmit={handleDelimaLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider mb-2">1. Pilih Peranan Akses Portal</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { role: 'student', label: 'Pelajar DELIMa', icon: MessageSquare },
                  { role: 'parent', label: 'Ibu Bapa / Penjaga', icon: Users },
                  { role: 'counselor', label: 'Guru Kaunselor', icon: ShieldAlert },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.role}
                      type="button"
                      onClick={() => { setCurrentRole(item.role); setLoginError(''); }}
                      className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
                        currentRole === item.role
                          ? `${activeTheme.primary} border-transparent shadow-lg scale-105 font-bold`
                          : `border-slate-300/40 dark:border-slate-700/50 hover:bg-slate-500/10 opacity-75`
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-[11px] text-center leading-tight">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider mb-1">
                {currentRole === 'student' ? '2. ID DELIMa Murid (@moe-dl.edu.my)' : currentRole === 'counselor' ? '2. ID DELIMa Guru (@moe-dl.edu.my)' : '2. E-mel Terdaftar Ibu Bapa'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={delimaId}
                  onChange={(e) => setDelimaId(e.target.value)}
                  required
                  className={`w-full px-4 py-3 rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400`}
                  placeholder={
                    currentRole === 'student'
                      ? 'g-12345678@moe-dl.edu.my'
                      : currentRole === 'counselor'
                      ? 'g-98765432@moe-dl.edu.my'
                      : 'ibubapa@gmail.com'
                  }
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider mb-1">3. Kata Laluan / PIN Akses</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className={`w-full px-4 py-3 rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-slate-300 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400`}
                placeholder="••••••••"
              />
            </div>

            {loginError && (
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-600 text-xs font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoggingIn}
              className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm ${activeTheme.primary} shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50`}
            >
              {isLoggingIn ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Mengesahkan ID DELIMa...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Log Masuk Dengan Akses DELIMa</span>
                </>
              )}
            </button>
          </form>

          {/* Preset Quick Test Buttons for Demonstration */}
          <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-slate-500 block text-center">Akses Pantas Demo DELIMa:</span>
            <div className="grid grid-cols-3 gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => {
                  setCurrentRole('student');
                  setDelimaId('g-10293841@moe-dl.edu.my');
                  setPassword('demo1234');
                }}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 font-semibold text-slate-700 dark:text-slate-300 text-center"
              >
                Demo Murid
              </button>
              <button
                type="button"
                onClick={() => {
                  setCurrentRole('parent');
                  setDelimaId('penjaga.ahmad@gmail.com');
                  setPassword('demo1234');
                }}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 font-semibold text-slate-700 dark:text-slate-300 text-center"
              >
                Demo Ibu Bapa
              </button>
              <button
                type="button"
                onClick={() => {
                  setCurrentRole('counselor');
                  setDelimaId('g-98765432@moe-dl.edu.my');
                  setPassword('demo1234');
                }}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 font-semibold text-slate-700 dark:text-slate-300 text-center"
              >
                Demo Kaunselor
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${activeTheme.bg} flex flex-col transition-all duration-500 font-sans relative`}>
      {/* Header Bar */}
      <header className={`sticky top-0 z-30 ${activeTheme.navBg} border-b shadow-sm px-4 py-3 backdrop-blur-md`}>
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CuteMascot mood={mascotMood} size="small" onClick={handleMascotTap} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base tracking-tight">MindCare Connect</h1>
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${activeTheme.badgeBg}`}>
                  {currentRole === 'student' ? 'Pelajar DELIMa' : currentRole === 'parent' ? 'Ibu Bapa' : 'Guru Kaunselor'}
                </span>
              </div>
              <p className={`text-xs ${activeTheme.subtext}`}>ID: {userProfile?.delimaId || 'DELIMa User'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleAudio}
              className={`p-2.5 rounded-2xl border transition flex items-center gap-1.5 text-xs font-semibold ${
                isAudioPlaying
                  ? 'bg-emerald-500 text-white border-emerald-400 shadow-lg animate-pulse'
                  : 'bg-white/60 dark:bg-slate-900/60 border-slate-300/60 dark:border-slate-800 hover:bg-white/90'
              }`}
              title={isAudioPlaying ? 'Matikan Bunyi Hujan Penenang' : 'Mainkan Bunyi Hujan Penenang'}
            >
              {isAudioPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
              <span className="hidden sm:inline">{isAudioPlaying ? 'Hujan Aktif' : 'Bunyi Penenang'}</span>
            </button>

            {currentRole === 'student' && (
              <button
                onClick={() => setShowBreathingModal(true)}
                className="hidden md:flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30 hover:bg-teal-500/20 transition"
              >
                <Wind className="w-4 h-4" />
                <span>Nafas Tenang</span>
              </button>
            )}

            <button
              onClick={() => setShowThemeModal(true)}
              className="p-2.5 rounded-2xl bg-white/60 dark:bg-slate-900/60 border border-slate-300/60 dark:border-slate-800 hover:bg-white/90 transition flex items-center gap-1 text-xs font-semibold"
            >
              <Palette className="w-4 h-4 text-rose-500" />
              <span className="hidden sm:inline">Tema ({activeTheme.name.split(' ')[0]})</span>
            </button>

            <button
              onClick={() => {
                setIsLoggedIn(false);
                setUserProfile(null);
                setDelimaId('');
                setPassword('');
              }}
              className="p-2.5 rounded-2xl bg-rose-500/10 text-rose-600 hover:bg-rose-500 hover:text-white transition flex items-center gap-1 text-xs font-bold"
              title="Log Keluar DELIMa"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Log Keluar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Role Content */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:p-6">
        {currentRole === 'student' && (
          <StudentChatView
            activeTheme={activeTheme}
            messages={messages}
            inputText={inputText}
            setInputText={setInputText}
            handleSendMessage={handleSendMessage}
            isThinking={isThinking}
            chatEndRef={chatEndRef}
            setShowCheckupModal={setShowCheckupModal}
            mascotMood={mascotMood}
            mascotQuote={mascotQuote}
            handleMascotTap={handleMascotTap}
            setShowBreathingModal={setShowBreathingModal}
            userProfile={userProfile}
          />
        )}

        {currentRole === 'parent' && (
          <ParentDashboardView
            activeTheme={activeTheme}
            parentHints={parentHints}
          />
        )}

        {currentRole === 'counselor' && (
          <CounselorDashboardView
            activeTheme={activeTheme}
            crisisAlerts={crisisAlerts}
            setCrisisAlerts={setCrisisAlerts}
            studentsList={studentsList}
            setStudentsList={setStudentsList}
          />
        )}
      </main>

      {/* Breathing Exercise Modal */}
      {showBreathingModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`max-w-md w-full p-6 rounded-3xl ${activeTheme.card} border ${activeTheme.border} text-center space-y-5 shadow-2xl relative`}>
            <button
              onClick={() => setShowBreathingModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕
            </button>
            <div className="flex justify-center">
              <CuteMascot mood="breathing" size="large" />
            </div>
            <div>
              <h3 className="font-black text-lg">Sesi Nafas Tenang (4-4-4)</h3>
              <p className={`text-xs ${activeTheme.subtext} mt-1`}>
                Ikuti ritme di bawah untuk menenangkan minda & mengurangkan kegelisahan.
              </p>
            </div>
            <div className="py-6 flex flex-col items-center justify-center">
              <div className="w-28 h-28 rounded-full border-4 border-teal-400/40 flex items-center justify-center relative animate-pulse">
                <span className="text-3xl font-black text-teal-500">{breathingTimer}</span>
              </div>
              <span className="mt-4 font-bold text-sm tracking-wide text-teal-600 dark:text-teal-400 uppercase">
                {breathingPhase}
              </span>
            </div>
            <button
              onClick={() => setShowBreathingModal(false)}
              className={`w-full py-3 rounded-2xl ${activeTheme.primary} font-bold text-xs shadow-md`}
            >
              Selesai & Ringankan Minda
            </button>
          </div>
        </div>
      )}

      {/* 6-Hour Mood Check-in Modal */}
      {showCheckupModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`max-w-md w-full p-6 rounded-3xl ${activeTheme.card} border ${activeTheme.border} space-y-4 shadow-2xl relative`}>
            <button
              onClick={() => setShowCheckupModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕
            </button>
            <div className="text-center">
              <CuteMascot mood="happy" size="normal" />
              <h3 className="font-black text-lg mt-2">Semakan Emosi 6-Jam</h3>
              <p className={`text-xs ${activeTheme.subtext} mt-0.5`}>
                Bagaimanakah perasaan anda dalam beberapa jam kebelakangan ini?
              </p>
            </div>
            {!checkupDone ? (
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: 'Gembira', icon: Smile, color: 'text-emerald-500' },
                    { label: 'Biasa', icon: Meh, color: 'text-amber-500' },
                    { label: 'Sedih', icon: Frown, color: 'text-rose-500' },
                    { label: 'Gelisah', icon: AlertTriangle, color: 'text-purple-500' },
                  ].map((m) => {
                    const Icon = m.icon;
                    return (
                      <button
                        key={m.label}
                        onClick={() => setCheckupMood(m.label)}
                        className={`p-3 rounded-2xl border flex flex-col items-center gap-1 transition ${
                          checkupMood === m.label
                            ? 'border-rose-400 bg-rose-50 dark:bg-rose-950/40 font-bold scale-105'
                            : 'border-slate-200 dark:border-slate-800 opacity-80 hover:opacity-100'
                        }`}
                      >
                        <Icon className={`w-6 h-6 ${m.color}`} />
                        <span className="text-[11px]">{m.label}</span>
                      </button>
                    );
                  })}
                </div>
                <textarea
                  value={checkupNote}
                  onChange={(e) => setCheckupNote(e.target.value)}
                  placeholder="Nota singkat luahan (pilihan)..."
                  rows={3}
                  className="w-full p-3 rounded-2xl bg-white/60 dark:bg-slate-900/60 border border-slate-300 dark:border-slate-700 text-xs focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
                <button
                  onClick={handleCompleteCheckup}
                  disabled={!checkupMood}
                  className={`w-full py-3 rounded-2xl ${activeTheme.primary} font-bold text-xs shadow-md disabled:opacity-50`}
                >
                  Simpan Semakan Emosi
                </button>
              </div>
            ) : (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                <p className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
                  Terima kasih! Semakan emosi anda telah disimpan.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Theme Selector Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`max-w-lg w-full p-6 rounded-3xl ${activeTheme.card} border ${activeTheme.border} space-y-4 shadow-2xl relative max-h-[85vh] overflow-y-auto`}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-black text-base flex items-center gap-2">
                <Palette className="w-5 h-5 text-rose-500" />
                <span>Pilih Tema Estetik (10 Tema)</span>
              </h3>
              <button onClick={() => setShowThemeModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Object.keys(THEMES).map((key) => {
                const t = THEMES[key];
                return (
                  <button
                    key={key}
                    onClick={() => { setThemeKey(key); setShowThemeModal(false); }}
                    className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between gap-2 ${
                      themeKey === key
                        ? 'border-rose-400 ring-2 ring-rose-400/50 bg-rose-50/50 dark:bg-slate-900'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div>
                      <span className="font-bold text-xs block">{t.name}</span>
                      <span className="text-[10px] opacity-70 block">{t.tagline}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StudentChatView({
  activeTheme, messages, inputText, setInputText, handleSendMessage,
  isThinking, chatEndRef, setShowCheckupModal, mascotMood, mascotQuote, handleMascotTap,
  setShowBreathingModal, userProfile
}) {
  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-4xl mx-auto space-y-4">
      
      <div className={`p-4 rounded-3xl ${activeTheme.card} border ${activeTheme.border} flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm`}>
        <div className="flex items-center gap-3">
          <CuteMascot mood={mascotMood} size="normal" onClick={handleMascotTap} quote={mascotQuote} />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm">Mochi the AI Care Buddy</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500 font-bold border border-rose-500/20">
                DELIMa Verified
              </span>
            </div>
            <p className={`text-xs mt-0.5 ${activeTheme.subtext}`}>
              Log Masuk Akaun Murid: {userProfile?.delimaId || 'DELIMa Student'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => setShowBreathingModal(true)}
            className="text-xs font-bold px-3 py-2 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30 hover:bg-teal-500/20 transition flex items-center gap-1.5"
          >
            <Wind className="w-3.5 h-3.5" />
            <span>Nafas Tenang</span>
          </button>
          
          <button
            onClick={() => setShowCheckupModal(true)}
            className="text-xs font-bold px-3 py-2 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition flex items-center gap-1.5"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Check-in 6-Jam</span>
          </button>
        </div>
      </div>

      <div className={`flex-1 overflow-y-auto p-4 rounded-3xl ${activeTheme.card} border ${activeTheme.border} space-y-4 shadow-sm relative`}>
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
          >
            {msg.sender === 'ai' && (
              <div className="mr-2 self-end mb-1">
                <CuteMascot mood="happy" size="small" />
              </div>
            )}
            <div className={`max-w-[80%] md:max-w-[70%] rounded-3xl px-4 py-3 text-sm shadow-sm ${
              msg.sender === 'user' ? activeTheme.chatUser : activeTheme.chatAi
            }`}>
              <div className="flex items-center justify-between gap-4 mb-1">
                <span className="text-[10px] font-extrabold opacity-70">
                  {msg.sender === 'user' ? 'Anda' : 'Mochi ☁️'}
                </span>
                <span className="text-[10px] opacity-50">{msg.time}</span>
              </div>
              <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
            </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex justify-start items-center gap-2">
            <CuteMascot mood="breathing" size="small" />
            <div className={`rounded-2xl px-4 py-2.5 text-xs ${activeTheme.chatAi} flex items-center gap-2 font-medium`}>
              <Sparkles className="w-4 h-4 animate-spin text-rose-400" />
              <span>Mochi sedang fikirkan kata-kata manis untuk awak...</span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <form onSubmit={handleSendMessage} className="flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Taip luahan atau cerita apa sahaja dengan Mochi..."
          className={`flex-1 px-5 py-3.5 rounded-2xl ${activeTheme.card} border ${activeTheme.border} text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 shadow-sm`}
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isThinking}
          className={`px-6 py-3.5 rounded-2xl ${activeTheme.primary} font-bold text-sm flex items-center gap-2 shadow-lg transition active:scale-95 disabled:opacity-50`}
        >
          <span>Hantar</span>
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}

function ParentDashboardView({ activeTheme, parentHints }) {
  const filteredParentHints = parentHints.filter(
    (hint) => hint.level === 'Ringan' || hint.level === 'Sederhana'
  );

  return (
    <div className="space-y-6">
      <div className={`p-6 rounded-3xl ${activeTheme.card} border ${activeTheme.border} relative overflow-hidden shadow-sm`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-5 h-5 text-indigo-500" />
              <h2 className="text-xl font-black tracking-tight">Portal Pemantauan & Petunjuk Emosi Anak (Aksara DELIMa)</h2>
            </div>
            <p className={`text-xs ${activeTheme.subtext}`}>
              Laporan emosi diproses secara halus oleh AI tanpa menceroboh privasi luahan anak secara langsung.
            </p>
          </div>
          <div className="flex items-center gap-2 bg-indigo-500/10 px-3.5 py-2 rounded-2xl border border-indigo-500/20 text-xs font-semibold text-indigo-500">
            <Lock className="w-4 h-4 shrink-0" />
            <span>Kerahsiaan Dijamin: Hanya maklumat tahap Ringan & Sederhana dipaparkan.</span>
          </div>
        </div>
      </div>

      <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>
            <strong>Nota Etika Kerahsiaan DELIMa:</strong> Portal ibu bapa menyediakan petunjuk amaran emosi tahap <strong>Ringan</strong> dan <strong>Sederhana</strong> untuk aktiviti keibubapaan mesra. Sekiranya terdapat emosi berisiko tinggi, Guru Kaunseling Sekolah akan mengendalikannya secara terus demi keselamatan pelajar.
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`md:col-span-2 p-5 rounded-3xl ${activeTheme.card} border ${activeTheme.border} space-y-4 shadow-sm`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-indigo-500" />
              <h3 className="font-extrabold text-sm">Pemantauan Masa Skrin (Screen Time)</h3>
            </div>
            <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold border border-emerald-500/20">
              Purata Harian: 4j 25m
            </span>
          </div>

          <div className="h-48 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={SCREEN_TIME_DATA}>
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} unit="m" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '16px', fontSize: '12px', color: '#fff' }} />
                <Bar dataKey="social" name="Media Sosial" stackId="a" fill="#ec4899" radius={[0, 0, 0, 0]} />
                <Bar dataKey="gaming" name="Permainan Video" stackId="a" fill="#8b5cf6" radius={[0, 0, 0, 0]} />
                <Bar dataKey="study" name="Aplikasi Belajar" stackId="a" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
            {APP_USAGE_PIE.map((app) => (
              <div key={app.name} className="p-2.5 rounded-2xl bg-white/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800">
                <span className="block font-bold" style={{ color: app.color }}>{app.name}</span>
                <span className="text-slate-500 text-[11px]">{app.value}% masa skrin</span>
              </div>
            ))}
          </div>
        </div>

        <div className={`p-5 rounded-3xl ${activeTheme.card} border ${activeTheme.border} space-y-4 shadow-sm flex flex-col justify-between`}>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-indigo-500" />
              <h3 className="font-extrabold text-sm">Trend Indeks Emosi Minggu Ini</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">Graf berdasarkan luahan chat AI & check-up 6 jam anak</p>

            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={MOOD_TREND}>
                  <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} />
                  <YAxis domain={[0, 10]} hide />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '11px', color: '#fff' }} />
                  <Area type="monotone" dataKey="score" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs space-y-1">
            <span className="font-extrabold text-indigo-500 block">Status Emosi Keseluruhan:</span>
            <p className="opacity-90">Stabil dengan sedikit tekanan emosi sosial pada pertengahan minggu.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="font-extrabold text-base">Petunjuk Emosi & Cadangan Mesra Keibubapaan (Ringan & Sederhana)</h3>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-200 dark:bg-slate-800">
            {filteredParentHints.length} Rekod Paparan
          </span>
        </div>

        <div className="space-y-4">
          {filteredParentHints.map((hint) => (
            <div
              key={hint.id}
              className={`p-5 rounded-3xl ${activeTheme.card} border ${activeTheme.border} shadow-sm space-y-3 relative overflow-hidden`}
            >
              <div className="flex items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-bold px-3 py-1 rounded-full border ${
                    hint.level === 'Sederhana'
                      ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                      : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                  }`}>
                    {hint.category}
                  </span>
                  <span className="text-xs text-slate-400">{hint.date}</span>
                </div>
                <span className="text-xs font-semibold text-slate-500">Tahap Emosi: {hint.level}</span>
              </div>

              <div className="space-y-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Petunjuk Emosi (Hint):</h4>
                  <p className="text-sm font-semibold leading-relaxed">{hint.hint}</p>
                </div>

                <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs space-y-1">
                  <span className="font-extrabold text-indigo-500 flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-rose-500" /> Cadangan Tindakan Eratkan Silaturahim (AI Parenting Assistant):
                  </span>
                  <p className="opacity-90 leading-relaxed">{hint.advice}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CounselorDashboardView({ activeTheme, crisisAlerts, setCrisisAlerts, studentsList, setStudentsList }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRisk, setFilterRisk] = useState('Semua');

  const handleResolveAlert = (id) => {
    setCrisisAlerts((prev) => prev.map((a) => a.id === id ? { ...a, status: 'TELAH DITERIMA & SELESAI' } : a));
  };

  const highRiskStudents = studentsList.filter((s) => s.riskLevel === 'Tinggi');

  const filteredStudents = studentsList.filter((s) => {
    const matchSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.class.toLowerCase().includes(searchTerm.toLowerCase()) || s.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchFilter = filterRisk === 'Semua' || s.riskLevel === filterRisk;
    return matchSearch && matchFilter;
  });

  return (
    <div className="space-y-6">
      <div className={`p-6 rounded-3xl ${activeTheme.card} border ${activeTheme.border} shadow-sm relative overflow-hidden`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldAlert className="w-6 h-6 text-rose-500" />
              <h2 className="text-xl font-black tracking-tight">Portal Guru Kaunselor Sekolah (DELIMa Integrated)</h2>
            </div>
            <p className={`text-xs ${activeTheme.subtext}`}>
              Pengurusan menyeluruh kesemua pelajar terdaftar di bawah ID DELIMa sekolah.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="px-3 py-1.5 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 animate-bounce" />
              <span>{highRiskStudents.length} Risiko Tinggi</span>
            </div>
            <div className="px-3 py-1.5 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 text-xs font-bold">
              <span>{studentsList.filter(s => s.riskLevel === 'Sederhana').length} Risiko Sederhana</span>
            </div>
            <div className="px-3 py-1.5 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 text-xs font-bold">
              <span>{studentsList.filter(s => s.riskLevel === 'Ringan').length} Risiko Ringan</span>
            </div>
          </div>
        </div>
      </div>

      {highRiskStudents.length > 0 && (
        <div className="p-5 rounded-3xl bg-rose-500/10 border-2 border-rose-500/50 shadow-lg space-y-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
              </span>
              <h3 className="font-extrabold text-base text-rose-600 dark:text-rose-400 uppercase tracking-wide">
                PERHATIAN SEGERA: Pelajar Berisiko Tinggi ({highRiskStudents.length})
              </h3>
            </div>
            <span className="text-xs bg-rose-500 text-white font-bold px-3 py-1 rounded-full animate-pulse">
              Keutamaan Intervensi Kaunseling
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {highRiskStudents.map((student) => (
              <div
                key={student.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-800 shadow-md space-y-3 relative"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center font-black text-sm shadow">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm">{student.name}</h4>
                      <p className="text-xs text-slate-500">{student.class} • {student.email}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-rose-100 text-rose-700 font-extrabold text-[10px] border border-rose-300">
                    RISIKO TINGGI
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs">
                  <span className="font-bold text-rose-600 dark:text-rose-400 block mb-1">Kesimpulan Emosi AI:</span>
                  <p className="text-slate-700 dark:text-slate-200 font-medium leading-relaxed">{student.aiSummary}</p>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    onClick={() => alert(`Memulakan langkah keselamatan & jemputan khas kaunseling untuk ${student.name}...`)}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition shadow flex items-center gap-1"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Tindakan Wajar Segera</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        <h3 className="font-extrabold text-base flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-rose-500" />
          <span>Notis Amaran Isu Spesifik (Red Flag System)</span>
        </h3>

        <div className="space-y-3">
          {crisisAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-3xl ${activeTheme.card} border ${
                alert.severity.includes('KRITIKAL') ? 'border-rose-400/60 bg-rose-50/50 dark:bg-rose-950/10' : activeTheme.border
              } shadow-sm space-y-3`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-sm">{alert.studentName}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      alert.severity.includes('KRITIKAL')
                        ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/40'
                        : 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40'
                    }`}>
                      {alert.severity}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">{alert.studentEmail} • {alert.timestamp}</span>
                </div>

                <span className={`text-[11px] px-2.5 py-0.5 rounded-xl font-bold border ${
                  alert.status === 'BELUM DIPROSES'
                    ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30'
                    : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                }`}>
                  {alert.status}
                </span>
              </div>

              <p className="text-xs font-medium text-slate-700 dark:text-slate-300">{alert.aiSummary}</p>

              <div className="flex items-center justify-end gap-2">
                {alert.status === 'BELUM DIPROSES' && (
                  <button
                    onClick={() => handleResolveAlert(alert.id)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                  >
                    Tanda Selesai Intervensi
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4 pt-4 border-t border-slate-300/50 dark:border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-extrabold text-base flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-500" />
              <span>Senarai Keseluruhan Pelajar DELIMa & Kesimpulan Emosi AI</span>
            </h3>
            <p className="text-xs text-slate-500">Semua kesimpulan emosi pelajar terdaftar dipaparkan untuk rekod kaunselor.</p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <input
              type="text"
              placeholder="Cari ID DELIMa, nama..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-slate-300 dark:border-slate-700 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
            
            <div className="flex bg-slate-200/80 dark:bg-slate-900/80 p-1 rounded-xl text-xs font-bold border border-slate-300/50 dark:border-slate-800">
              {['Semua', 'Tinggi', 'Sederhana', 'Ringan'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setFilterRisk(lvl)}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    filterRisk === lvl
                      ? 'bg-indigo-600 text-white shadow'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {filteredStudents.map((student) => (
            <div
              key={student.id}
              className={`p-4 rounded-3xl ${activeTheme.card} border ${
                student.riskLevel === 'Tinggi'
                  ? 'border-rose-400/80 bg-rose-50/30 dark:bg-rose-950/10'
                  : student.riskLevel === 'Sederhana'
                  ? 'border-amber-300 dark:border-amber-800'
                  : activeTheme.border
              } shadow-sm transition hover:shadow-md`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl ${student.avatarColor} text-white flex items-center justify-center font-extrabold text-sm shadow shrink-0`}>
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-sm">{student.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 font-bold">
                        {student.class}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">{student.email} • Aktif: {student.lastActive}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 justify-between md:justify-end">
                  <span className={`text-xs px-3 py-1 rounded-full font-bold border ${
                    student.riskLevel === 'Tinggi'
                      ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-500/40 animate-pulse'
                      : student.riskLevel === 'Sederhana'
                      ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-500/40'
                      : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-500/40'
                  }`}>
                    Risiko {student.riskLevel}
                  </span>

                  <button
                    onClick={() => {
                      const newNote = prompt(`Kemaskini nota/status intervensi untuk ${student.name}:`, student.counselorAction);
                      if (newNote) {
                        setStudentsList(prev => prev.map(s => s.id === student.id ? { ...s, counselorAction: newNote } : s));
                      }
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white transition text-xs font-bold"
                  >
                    {student.counselorAction}
                  </button>
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-800/80 text-xs">
                <span className="font-extrabold opacity-75 block mb-1">
                  Kesimpulan Emosi & Luahan AI:
                </span>
                <p className="opacity-90 leading-relaxed bg-white/50 dark:bg-slate-900/50 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800">
                  {student.aiSummary}
                </p>
              </div>
            </div>
          ))}

          {filteredStudents.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-500">
              Tiada rekod pelajar ditemui mengikut carian ini.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}