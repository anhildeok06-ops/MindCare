MINDCARE CONNECT — PERSIAPAN PROJEK ANDROID
===========================================

Folder ini membungkus kod React sedia ada dengan Vite, Tailwind CSS dan Capacitor.
Kod asal disimpan di src/App.jsx.

KEPERLUAN
- Windows 10/11
- Node.js LTS (disyorkan Node 22)
- Android Studio dengan Android SDK
- Sambungan internet untuk memasang pakej

LANGKAH 1 — EKSTRAK
Ekstrak ZIP ini ke folder mudah, contoh C:\Projects\MindCareConnect-Android

LANGKAH 2 — BUKA TERMINAL DALAM FOLDER PROJEK
Dalam File Explorer, buka folder projek. Klik bar alamat, taip cmd, tekan Enter.

LANGKAH 3 — PASANG PAKEJ
Jalankan:
  npm install

LANGKAH 4 — BINA APLIKASI WEB
Jalankan:
  npm run build

LANGKAH 5 — CIPTA PROJEK ANDROID
Jalankan:
  npx cap add android

Jika arahan menyatakan platform Android sudah wujud, jangan jalankan langkah ini lagi.

LANGKAH 6 — SALIN FAIL WEB KE PROJEK ANDROID
Jalankan:
  npx cap sync android

LANGKAH 7 — BUKA ANDROID STUDIO
Jalankan:
  npx cap open android

Dalam Android Studio, tunggu Gradle selesai sync. Untuk menguji, pilih emulator/telefon
dan tekan Run. Untuk menghasilkan APK ujian, pilih:
  Build > Build Bundle(s) / APK(s) > Build APK(s)

Android Studio akan menunjukkan pautan "locate" selepas APK selesai dibina.

JIKA ANDA MENGUBAH KOD KEMUDIAN
Jalankan semula:
  npm run build
  npx cap sync android
Kemudian bina/run semula dalam Android Studio.

PENTING — STATUS KOD INI
1. Panggilan Gemini dalam kod asal mempunyai apiKey kosong. AI sebenar tidak akan berfungsi
   sehingga sambungan API dikonfigurasi dengan cara yang selamat.
2. Log masuk DELIMa dalam kod ini ialah simulasi di sisi klien, bukan pengesahan rasmi KPM.
   Jangan kumpul kata laluan sebenar atau dakwa aplikasi ini disahkan KPM.
3. Data pelajar, rekod kaunselor, amaran krisis dan carta dalam kod ialah data contoh/demo.
4. Oleh sebab aplikasi berkaitan emosi pelajar, jangan gunakan dengan pelajar sebenar dahulu.
   Perlu backend selamat, kawalan akses sebenar, dasar privasi, semakan pihak sekolah/KPM,
   dan prosedur tindakan krisis yang disahkan.
5. Jangan masukkan API key rahsia dalam kod frontend atau repo GitHub awam.

Jika berlaku ralat, salin mesej ralat penuh dan hantarkan untuk dibantu.
